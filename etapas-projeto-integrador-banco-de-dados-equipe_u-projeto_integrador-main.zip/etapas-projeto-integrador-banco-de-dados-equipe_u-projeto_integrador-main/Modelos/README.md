Aqui dentro está os modelos conceitual e lógico.
